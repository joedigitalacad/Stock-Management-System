<?php 
	include '../models/Products.php';
	$product = new Products();

 ?>