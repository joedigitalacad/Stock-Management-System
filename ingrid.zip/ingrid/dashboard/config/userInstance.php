<?php 
	include '../models/Users.php';
	$user = new Users();

 ?>