<?php 

// INSERT INTO `users` (`id`, `fullname`, `username`, `password`, `email`, `role`, `matricule`, `department`, `address`, `number`, `image`) VALUES (NULL, 'Ebune joseph Achancho', 'ebune', MD5('ebune'), 'ebuneachancho@gmail.com', 'admin', 'STK001', 'IT Department', 'Bonduma Gate, Molyko Buea, Cameroon', '653468306', '');



 ?>