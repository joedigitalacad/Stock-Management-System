<!DOCTYPE html>
<html>
<head>
	<title>Stock Management System</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css.map">
	<script type="text/javascript" src="vendor/jquery-1.12.4.min.js"></script>
	<script type="text/javascript" src="vendor/modernizr-2.8.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/bootstrap.bundle.js"></script>
</head>
<body style="background: #ccc;">