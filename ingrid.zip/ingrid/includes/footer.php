<footer>
		<div class="container">
			<div class="row">
				<!-- <p style="text-align: center;">Copyright @ <?php date('Y');?> <a href="joedigitalacademy.com">Joe Digital Acad</a></p> -->
			</div>
		</div>
	</footer>
</div><!-- wrapper -->
</body>
</html>